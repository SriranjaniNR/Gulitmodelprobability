<!DOCTYPE html>
<html lang="en">
<head>
	<title>Data Leakage Detection</title>
	<meta charset="utf-8" />
	
	<link rel="stylesheet" href="stylesheet.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body class="body">
	
	<header class="mainHeader">
		<nav><ul>
			<li class="active"><a href="#">Home</a></li>
			<li><a href="register.html">Registration</a></li>
			<li><a href="userlogin.php">UserLogin</a></li>
			<li><a href="adminlogin.php">AdminLogin</a></li>
		</ul></nav>
	</header>
		
	<div class="mainContent1">
		<div class="content">	
				<article class="topcontent1">	
					<header>
						<h2><a href="#" rel="bookmark" title="Permalink to this POST TITLE">Data Leakage Detection</a></h2>
					</header>
					
					<footer>
						<p class="post-info"></p>
					</footer>
					
				</article>	
		</div>
	</div>
	
	

</body>
</html>